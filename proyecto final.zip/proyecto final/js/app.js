document.addEventListener("DOMContentLoaded", function() {

    //Aula Virtual
    const formAulaVirtual = document.getElementById('formAulaVirtual');
    if(formAulaVirtual) {
        formAulaVirtual.addEventListener('submit', function(e) {
            e.preventDefault(); 
            const user = document.getElementById('loginUser').value.trim();
            const pass = document.getElementById('loginPass').value.trim();

            if(user === "cenfo" && pass === "123") {
                Swal.fire({
                    title: '¡Acceso Concedido!',
                    text: 'Bienvenido al entorno virtual.',
                    icon: 'success',
                    confirmButtonColor: '#ff6b35'
                }).then(() => {
                    window.location.href = "index.html"; 
                });
            } else {
                Swal.fire({
                    title: 'Credenciales inválidas',
                    text: 'El usuario o contraseña no son correctos.',
                    icon: 'error',
                    confirmButtonColor: '#0a2342'
                });
            }
        });
    }

    emailjs.init("RR1u9F6msGb-uhrVm");

    // Contacto
    const formContacto = document.getElementById('formContacto');
    if (formContacto) {
        formContacto.addEventListener('submit', function(e) {
            e.preventDefault();

            const nombre = document.getElementById('nombreContacto').value.trim();
            const email = document.getElementById('emailContacto').value.trim();
            const mensaje = document.getElementById('mensajeContacto').value.trim();

            if (nombre === "" || email === "" || mensaje === "") {
                Swal.fire({
                    title: 'Campos incompletos',
                    text: 'Por favor, rellena todos los campos antes de enviar.',
                    icon: 'warning',
                    confirmButtonColor: '#0a2342'
                });
                return;
            }

            Swal.fire({
                title: 'Enviando mensaje...',
                text: 'Estamos procesando tu solicitud.',
                allowOutsideClick: false,
                didOpen: () => { Swal.showLoading(); }
            });

            emailjs.sendForm('service_6tbcvbf', 'template_contacto', this)
                .then(function() {
                    Swal.fire({
                        title: '¡Mensaje enviado!',
                        text: 'Nos comunicaremos contigo pronto.',
                        icon: 'success',
                        confirmButtonColor: '#ff6b35'
                    });
                    formContacto.reset();
                }, function(error) {
                    Swal.fire({
                        title: 'Error de envío',
                        text: 'No pudimos procesar tu mensaje. Intenta más tarde.',
                        icon: 'error',
                        confirmButtonColor: '#0a2342'
                    });
                    console.log('Error:', error);
                });
        });
    }

    // Boletín
    const formBoletin = document.getElementById('formBoletin');
    if (formBoletin) {
        formBoletin.addEventListener('submit', function(e) {
            e.preventDefault();
            const emailBoletin = document.getElementById('emailBoletin').value.trim();

            if (emailBoletin === "") {
                Swal.fire({
                    title: 'Correo necesario',
                    text: 'Por favor, ingresa tu correo para suscribirte.',
                    icon: 'warning',
                    confirmButtonColor: '#0a2342'
                });
            } else {
                emailjs.sendForm('service_6tbcvbf', 'template_boletin', this)
                    .then(function() {
                        Swal.fire({
                            title: '¡Suscripción lista!',
                            text: 'Gracias por unirte a nuestro boletín.',
                            icon: 'success',
                            showConfirmButton: false,
                            timer: 3000
                        });
                        formBoletin.reset();
                    });
            }
        });
    }

    //Biblioteca Virtual
    const botonesBiblioteca = document.querySelectorAll('#btnBiblioteca');
    
    if(botonesBiblioteca.length > 0) {
        botonesBiblioteca.forEach(boton => {
            boton.addEventListener('click', function(e) {
                e.preventDefault();
                
                Swal.fire({
                    title: 'Acceso Restringido',
                    text: 'La Biblioteca virtual es de uso exclusivo para estudiantes activos. Por favor, ingresa desde el aula virtual.',
                    icon: 'info',
                    confirmButtonColor: '#0a2342', 
                    confirmButtonText: 'Ir al Aula Virtual',
                    showCancelButton: true,
                    cancelButtonText: 'Cerrar',
                    cancelButtonColor: '#d33'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = "aula-virtual.html";
                    }
                });
            });
        });
    }

    //Selectores
    function habilitarSelectorPdf(idSelect) {
        const select = document.getElementById(idSelect);

        if (select) {
            select.addEventListener('change', function() {
                const url = this.value; 
                
                if (url !== "") {
                    window.open(url, '_blank');
                    this.value = ""; 
                }
            });
        }
    }

    habilitarSelectorPdf('selectObras');
    habilitarSelectorPdf('selectTesis');
});